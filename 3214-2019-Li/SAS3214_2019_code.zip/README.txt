1) Run the cycle_plot_macros.sas first before running the examples.
2) The example used in the paper is contained in snacks.sas.
3) Before running the example flight.sas, please copy the flight dataset in the zip file into your sasuser directory.
